package Atv2Aluno;

public class Main {
    public static void main(String[] args) {

    Autor autor = new Autor("Willian, P. Young", "willian.gmail.com", 'M');

    Livro livro1 = new Livro("A cabana", "Willian P. Young", 20, 1);
    
    System.out.println(livro.toString());
    System.out.println(autor.toString());
    

}