package Atv1Professor;


public class Jogador {
    
    private double pontuacao;
    private String nome;
    private boolean ativado;
    
public double getPontuacao() {
     return pontuacao;
 }
 public void setPontuacao(double pontuacao) {
     this.pontuacao = pontuacao;
 }
 public String getNome() {
     return nome;
 }
 public void setNome(String nome) {
     this.nome = nome;
 }
 public boolean isAtivado() {
     return ativado;
 }
 public void setAtivado(boolean ativado) {
     this.ativado = ativado;
 } 
 
 }
 